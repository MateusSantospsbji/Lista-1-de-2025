#include <iostream>
#include <iomanip>

using namespace std;

// Elabore um programa que leia um caractere e depois o imprima como um número inteiro (suatabela ASCII).

int main(){
    
    double valor;

    printf("Digite:");
    
    
    cin >> valor;

    if (valor)
    
    cout << fixed << setprecision(1/2) << static_cast<double>(valor) << endl;

    return 0;
}