#include <iostream>
using namespace std;

//Faça um programa que leia dois valores do tipo float com um único comando cin, 
// e depois os imprima na ordem inversa.

int main(){
        
    int v1,v2;
    
    printf("Valor 1:");
    
    printf("\nValor 2:");

    cin >> v1 >> v2;
    

    if(v1, v2)
        
    cout << v1 <<"\n"<< v2 << endl;

    return 0;
}