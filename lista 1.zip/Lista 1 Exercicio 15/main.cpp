#include <iostream>

#define CONSTANTE 3.1415f

using namespace std;

// Escreva um programa que leia três variáveis: 
// um char, um int e um float. Depois, imprima:
// Na mesma linha, separados por espaço;
// Separados por tabulação;
// Um em cada linha.
// Use um único cout para cada formato.

int main(){
        
    char v1,v2,v3;
    
    int numero;

    cin >> v1 >> v2 >> v3 >> numero;
    

    if(v1, v2,v3,numero)
        
    cout << v1 <<"\n"<< v2 << "\n" << v3 << "\n"<< numero<< "\n" <<CONSTANTE << endl;

    return 0;
}