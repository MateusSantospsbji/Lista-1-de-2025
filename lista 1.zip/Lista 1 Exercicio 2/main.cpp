#include <iostream>

using namespace std;

//Escreva um programa que leia um número inteiro e depois o imprima na tela.

int main()
{
    int valor;

    cout << "Escreva um numero inteiro: ";
    cin >> valor;

    cout << "O numero digitado foi: " << valor << endl;

    return 0;
}
