#include <iostream>

using namespace std;

//Elabore um programa que leia 
// dia, mês e ano do tipo int
//e imprima no formato dd/mm/aaaa.

int main() {
    
    int dia, mes, ano;
    
    printf ("Qual e sua data de nacimento:");
   
    }
    if (dia < 0 || dia > 99) {
        
    } else {
        cout << dia << "/"<< mes << "/"<< ano;
    }
    
    if(entrada.size(dia, mes,ano) > 2){
        
        entrada = entrada.substr(0, 2);
        
    
        
    }

    return 0;
}
