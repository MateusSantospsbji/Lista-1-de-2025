#include <iostream>
#include <iomanip>

using namespace std;

//5.1

int main(){
    
    double valor, n;

    printf("Digite:");
    
    
    cin >> valor;

    if (valor)
    
    cout << fixed << setprecision(1/2) << static_cast<double>(valor) << endl;

    return 0;
}