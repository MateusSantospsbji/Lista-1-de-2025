#include <iostream>
using namespace std;

// Elabore um programa que contenha uma constante do tipo int usando o modificador const.
// Imprima o valor da constante

int main() {
    const int CONSTANTE = 42;

    cout << "Valor da constante: " << CONSTANTE << endl;

    return 0;
}
