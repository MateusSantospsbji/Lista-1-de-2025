#include <iostream>
#include <iomanip>

// Faça um programa que leia um número inteiro 
// imprima usando a formatação de ponto flutuante 
// (fixed,setprecision). Veja o que aconteceu.

// utilizar algo mais facil


using namespace std;

int main() {
    double valor;

    printf("Digite:");
    
    
    cin >> valor;

    if (valor)
    
    cout << fixed << setprecision(1) << static_cast<double>(valor) << endl;

    return 0;
}

