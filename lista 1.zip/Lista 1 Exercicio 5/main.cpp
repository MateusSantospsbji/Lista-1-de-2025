#include <iostream>
#include <iomanip>

using namespace std;

// Faça um programa que leia um valor do tipo float e depois o imprima como um número inteiro.
// Veja o que aconteceu.

int main() {
    float deci;

    cout << "Digite um número float: ";
    cin >> deci;

    int val = static_cast<int>(deci); 

    cout << val << endl;

    return 0;
}