#include <iostream>
#include <iomanip>
#include <string>
#include <cmath>

using namespace std;

int main() {
    string entrada;
    cout << "Digite um numero com virgula ou ponto: ";
    cin >> entrada;

    // Substituir vírgula por ponto
    size_t posVirgula = entrada.find(',');
    if (posVirgula != string::npos) entrada[posVirgula] = '.';

    // Converter string para double com verificação de valor real
    double n;
    try {
        n = stod(entrada);
    } catch (...) {
        cout << "Entrada inválida! Não é um número real." << endl;
        return 1;
    }

    // Variáveis de dígitos da parte inteira
    long long parteInteira = static_cast<long long>(n);
    int unidade = parteInteira % 10;
    int dezena = (parteInteira / 10) % 10;
    int centena = (parteInteira / 100) % 10;
    int milhar = (parteInteira / 1000) % 10;

    // Notação científica
    int expoente = 0;
    double valorReal = n;
    
    if (n != 0) {
        expoente = static_cast<int>(log10(abs(n)));
        valorReal = n / pow(10, expoente);
    }

    cout << fixed << setprecision(6);
    cout << "Numero: " << n << endl;
    cout << "Notaçao científica: " << valorReal << " * 10^" << expoente << endl;

    return 0;
}
