#include <iostream>

using namespace std;

//Escreva um programa que leia um caractere do tipo char e o imprima entre aspas duplas (" ").
//Exemplo: se for lido A, a saída será "A".

int main() {
    char letra;

    cout << "Digite um caractere: ";
    cin >> letra;

    cout << "\"" << letra << "\"" << endl;

    return 0;
}
