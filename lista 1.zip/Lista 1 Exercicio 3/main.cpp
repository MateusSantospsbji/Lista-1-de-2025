#include <iostream>
using namespace std;

// Escreva um programa que leia um número inteiro e depois imprima a mensagem "Valor lido:",
// seguido do valor. Use apenas um cout

int main() {
    int entrada;

    printf("Digite:");
    
    
    cin >> entrada;

    if (entrada)
        cout << entrada << endl;

    return 0;
}
