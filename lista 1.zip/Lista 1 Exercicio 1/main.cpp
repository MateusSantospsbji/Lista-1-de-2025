#include <iostream>

// Elabore um programa que escreva as mensagens 
// 'Início do programa' e 'Fim' na tela, 
// uma em cada linha, usando apenas um comando cout.

using namespace std;

int main()
{
    cout<<"Início do programa""\nfim";

    return 0;
}