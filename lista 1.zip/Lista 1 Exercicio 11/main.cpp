#include <iostream>

//Elabore um programa que contenha uma constante do tipo float usando o #define. 
// Imprima o valor dessa constante.

#define CONSTANTE 3.1415f

using namespace std;

int main() {
    cout << "Valor da constante: " << CONSTANTE << endl;
    return 0;
}