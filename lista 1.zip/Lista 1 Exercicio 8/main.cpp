#include <iostream>
#include <string>

using namespace std;

// Faça um programa que leia dois números inteiros e depois os imprima na ordem inversa em que foram lidos.

using namespace std;

int main() {
    
    int valor1, valor2;
    
    printf("Digite o valor 1:");
    
    cin >> valor1;
    
    printf("\nDigite o valor 2:");
    
    cin >> valor2;

    if (valor1,valor2)
    
    cout << valor2 <<"\n"<< valor1 << endl;

    return 0;
}
