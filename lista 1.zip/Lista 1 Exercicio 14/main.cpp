#include <iostream>
#include <iomanip>

using namespace std;

// Faça um programa que leia três caracteres e os imprima, um por linha. 
// Use apenas um cout para isso.

int main(){
        
    int v1,v2,v3;

    cin >> v1 >> v2 >> v3;

    if(v1, v2)
        
    cout << v1 <<"\n"<< v2 << endl;

    return 0;
}
